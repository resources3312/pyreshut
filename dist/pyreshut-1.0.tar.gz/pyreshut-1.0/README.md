# Pyreshut
Or Py-Reboot-Shutdown, this most correct name for this library.
I decided write this library only because all ways which
I found, use os util like shutdown or reboot, but I didnt 
like this way, and thats why you can use this library 


# Pip install 
```
pip install pyreshut
```


