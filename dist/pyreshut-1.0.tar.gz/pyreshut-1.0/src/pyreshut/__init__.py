While I just exist 
